// Aquí pondremos la lógica de los paneles desplegables en la siguiente etapa
